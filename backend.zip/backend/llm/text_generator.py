from groq import Groq

# Initialize Groq client
client = Groq(api_key="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")


# -----------------------------
# Follow-up email template
# -----------------------------
def generate_follow_up_email(company, role):

    template = f"""
Subject: Follow-up on Application for {role} at {company}

Dear Hiring Team,

I hope this email finds you well. I am writing to follow up on my application for the {role} position at {company}.

I am still very interested in the opportunity and would love to hear about the next steps in the process.

Best regards,
[Your Name]
"""

    return template.strip()


# -----------------------------
# Cold outreach email template
# -----------------------------
def generate_cold_outreach_email(company, role):

    template = f"""
Subject: Inquiry regarding {role} opportunities at {company}

Dear [Hiring Manager Name],

I have been following {company}'s work in the industry and am very impressed by your recent projects. I am reaching out to express my interest in potential {role} roles within your team.

I have attached my resume for your review and would welcome the chance to discuss how my skills could contribute to {company}.

Best regards,
[Your Name]
"""

    return template.strip()


# -----------------------------
# AI Interview Preparation
# -----------------------------
def generate_interview_prep(company, role):

    prompt = f"""
You are an expert interview coach.

A candidate is preparing for this role:

Role: {role}
Company: {company}

Generate role-specific interview preparation guidance.

The response MUST be tailored to the role.

Structure the answer with these sections:

1. Core Skills Required
2. Technical Topics To Study
3. Example Interview Questions
4. Portfolio / Project Preparation
5. How To Research {company}

Important:
- If the role is technical (developer, engineer, data scientist) include coding topics.
- If the role is analytical (data analyst, business analyst) include SQL, analysis and business thinking.
- If the role is design (UI/UX designer, product designer) include portfolio and design thinking.
- If the role is product or management include product thinking and stakeholder skills.

Be specific to the role {role}.
Use bullet points.
"""

    response = client.chat.completions.create(
    model="llama-3.1-8b-instant",
    messages=[
        {"role": "system", "content": "You are a career coach helping candidates prepare for interviews."},
        {"role": "user", "content": prompt}
    ],
    temperature=0.7,
)

    return response.choices[0].message.content