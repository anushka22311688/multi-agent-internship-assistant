import sqlite3
from datetime import datetime, timedelta

def init_db():
    conn = sqlite3.connect('applications.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            role TEXT NOT NULL,
            status TEXT NOT NULL,
            applied_date TEXT NOT NULL,
            follow_up_date TEXT
        )
    ''')
    conn.commit()
    conn.close()

def get_applications():
    conn = sqlite3.connect('applications.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM applications ORDER BY applied_date DESC')
    apps = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return apps

def add_application(company, role, status, applied_date):
    conn = sqlite3.connect('applications.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO applications (company, role, status, applied_date)
        VALUES (?, ?, ?, ?)
    ''', (company, role, status, applied_date))
    conn.commit()
    conn.close()

def update_status(app_id, company, role, status, applied_date):

    conn = sqlite3.connect('applications.db')
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE applications
        SET company = ?, role = ?, status = ?, applied_date = ?
        WHERE id = ?
    """, (company, role, status, applied_date, app_id))

    conn.commit()
    conn.close()