from pydantic import BaseModel
from typing import Optional

class Application(BaseModel):
    id: Optional[int] = None
    company: str
    role: str
    status: str
    applied_date: str
    follow_up_date: Optional[str] = None

class ApplicationCreate(BaseModel):
    company: str
    role: str
    status: str
    applied_date: str
