from datetime import datetime, timedelta

def get_today_tasks(applications):
    tasks = []
    today = datetime.now()

    for app in applications:
        applied_date = datetime.strptime(app['applied_date'], '%Y-%m-%d')
        days_passed = (today - applied_date).days

        if app['status'] == 'Applied' and days_passed >= 4:
            tasks.append({
                'id': app['id'],
                'company': app['company'],
                'task': f"Follow up with {app['company']}",
                'priority': 'High' if days_passed >= 7 else 'Medium'
            })
        elif app['status'] == 'Interview':
            tasks.append({
                'id': app['id'],
                'company': app['company'],
                'task': f"Prepare interview for {app['company']}",
                'priority': 'High'
            })
        elif days_passed >= 14 and app['status'] not in ['Rejected', 'Archived', 'Offer']:
            tasks.append({
                'id': app['id'],
                'company': app['company'],
                'task': f"Review application for {app['company']} (No response for 14 days)",
                'priority': 'Low'
            })

    return tasks
