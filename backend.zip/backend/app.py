from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from backend.database import init_db, get_applications, add_application, update_status
from backend.agents.decision_agent import get_today_tasks
from backend.llm.text_generator import (
    generate_follow_up_email,
    generate_cold_outreach_email,
    generate_interview_prep
)
import os
import json

app = FastAPI()

# Initialize Database
init_db()

# Mount static files
app.mount("/static", StaticFiles(directory="frontend/static"), name="static")

# Setup templates
templates = Jinja2Templates(directory="frontend/templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):

    apps = get_applications()
    tasks = get_today_tasks(apps)

    stats = {
        "total": len(apps),
        "follow_ups": len([t for t in tasks if "Follow up" in t['task']]),
        "interviews": len([a for a in apps if a['status'] == 'Interview'])
    }

    return templates.TemplateResponse(
        "home.html",
        {
            "request": request,
            "stats": stats,
            "tasks": tasks[:5]
        }
    )


@app.get("/pipeline", response_class=HTMLResponse)
async def pipeline(request: Request):

    apps = get_applications()

    return templates.TemplateResponse(
        "pipeline.html",
        {
            "request": request,
            "applications": apps
        }
    )


@app.post("/update/{app_id}")
async def update_app(
    app_id: int,
    company: str = Form(...),
    role: str = Form(...),
    status: str = Form(...),
    applied_date: str = Form(...)
):

    update_status(app_id, company, role, status, applied_date)

    return RedirectResponse("/pipeline", status_code=303)


@app.post("/add-application")
async def add_app(
    company: str = Form(...),
    role: str = Form(...),
    status: str = Form(...),
    applied_date: str = Form(...)
):

    add_application(company, role, status, applied_date)

    return RedirectResponse(url="/pipeline", status_code=303)


@app.get("/actions", response_class=HTMLResponse)
async def actions(request: Request):

    apps = get_applications()
    tasks = get_today_tasks(apps)

    return templates.TemplateResponse(
        "actions.html",
        {
            "request": request,
            "tasks": tasks
        }
    )


# Generate AI email
@app.get("/generate-email/{company}")
async def generate_email(company: str):

    apps = get_applications()

    role = ""

    for app in apps:
        if app["company"].lower() == company.lower():
            role = app["role"]
            break

    email = generate_follow_up_email(company, role)

    return {"email": email}

@app.get("/generate-interview-prep/{company}")
async def generate_interview_preparation(company: str):

    apps = get_applications()

    role = ""
    for a in apps:
        if a["company"].lower() == company.lower():
            role = a["role"]
            break

    prep = generate_interview_prep(company, role)

    return {"prep": prep}

# Mark task done
@app.get("/mark-done/{app_id}")
async def mark_done(app_id: int):

    apps = get_applications()

    for a in apps:
        if a["id"] == app_id:
            update_status(app_id, a["company"], a["role"], "Archived", a["applied_date"])
            break

    return RedirectResponse("/actions", status_code=303)


@app.get("/reports")
async def reports(request: Request):
    apps = get_applications()

    total = len(apps)
    interviews = sum(1 for a in apps if a["status"] == "Interview")
    followups = sum(1 for a in apps if a["status"] == "Follow-up")

    # status distribution for chart
    status_count = {}
    for a in apps:
        status = a["status"]
        status_count[status] = status_count.get(status, 0) + 1

    return templates.TemplateResponse("reports.html", {
        "request": request,
        "total": total,
        "interviews": interviews,
        "followups": followups,
        "status_data": status_count
    })


@app.get("/settings", response_class=HTMLResponse)
async def settings(request: Request):

    settings_data = {
        "name": "",
        "email": ""
    }

    if os.path.exists("settings.json"):
        with open("settings.json", "r") as f:
            settings_data = json.load(f)

    return templates.TemplateResponse(
        "settings.html",
        {
            "request": request,
            "settings": settings_data
        }
    )


@app.post("/save-settings")
async def save_settings(
    name: str = Form(...),
    email: str = Form(...),
    daily_tasks: str = Form(None),
    followup_notify: str = Form(None)
):

    daily_tasks_enabled = daily_tasks is not None
    followup_enabled = followup_notify is not None

    settings_data = {
        "name": name,
        "email": email,
        "daily_tasks": daily_tasks_enabled,
        "followup_notify": followup_enabled
    }

    with open("settings.json", "w") as f:
        json.dump(settings_data, f)

    return RedirectResponse("/settings", status_code=303)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)